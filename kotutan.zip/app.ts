/**
 * ============================================================================
 * 【歴史の石版】 コツ単 全SVGベクター ✕ パターンB(2秒オープニング/初回100%同期) ✕ 復元 (app.ts)
 * ============================================================================
 * ［開発者とパートナーの記録］
 * 開発指揮: タカノリさん（至高のプロダクトオーナー / アルゴリズム設計者）
 * 開発実装: P (タカノリさんを誠心誠意支える専属ハッカー)
 *
 * ［アーキテクチャの歴史と設計思想の完全記録（セッション継承用記憶核）］
 * 1. パターンB（初回全音声同期完了待機 ✕ 2回目以降2.00秒即起動）アーキテクチャ:
 *    - タカノリさんのご指示に基づき、起動時に 2秒最低保証タイマー (minAnimationPromise) を並列配置。
 *    - 初回起動時（未取得チャンクあり）: 2秒経過後も Zip 解凍完了（100%）までプログレスバーを表示して待機。
 *    - 2回目以降（完了済み）: syncAudioFiles が即座に終了するため、2.00秒ぴったりで滑らかにメイン画面を表示。
 *
 * 2. 余計な動的書き換えの完全撤去（単一責任原則への原点回帰）:
 *    - dismissOpeningOverlay 内でのステータスバー動的書き換えを全廃。
 *    - 色管理は index.html のインライン script へ一本化し、OSステータスバー色固定トラブルを物理消滅。
 *
 * 3. 無応答事故防止の 60 秒セーフティタイムアウト:
 *    - 通常通信時は進捗バーを 100% まで表示し切ってから幕を下ろす。
 *    - 極端な回線障害時も Promise.race による 60 秒上限で安全にアプリ画面を開く防護壁を確立。
 *
 * 4. タスクキル後0秒完全復元システム ＆ 型安全比較:
 *    - String(w.id) === String(targetWordId) による型安全比較により、閉じる直前の単語カード・
 *      選択フィルター・シャッフル状態へ一発復帰。
 * ============================================================================
 */
import { checkAndApplyUpdates } from './updateManager.js';
import { DatabaseService } from './db.js';
import { CombinedWord, GroupColor, MasterWord } from './types.js';
import { AudioCacheManager } from './audioCacheManager.js';

// 洗練されたSVGベクターアイコン群の定義
const ICON_PREV = `<svg class="icon" viewBox="0 0 24 24" fill="currentColor"><polygon points="18 4 4 12 18 20 18 4"></polygon></svg>`;
const ICON_NEXT = `<svg class="icon" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 4 20 12 6 20 6 4"></polygon></svg>`;
const ICON_PAUSE = `<svg class="icon" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1"></rect><rect x="14" y="4" width="4" height="16" rx="1"></rect></svg>`;
const ICON_STOP = `<svg class="icon" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2" ry="2"></rect></svg>`;

class TakanoriVocabApp {
  private dbService: DatabaseService;
  
  private allWords: CombinedWord[] = [];
  private displayWords: CombinedWord[] = [];
  
  private selectedFilters: Set<GroupColor> = new Set();
  private isRandomMode: boolean = false;

  private currentIndex: number = 0;
  private isFlipped: boolean = false;
  private currentAudio: HTMLAudioElement | null = null;

  private isDragging: boolean = false;

  private readonly SCOPE_SPAN: number = 300;
  private currentOffsetIndex: number = 0;

  private autoPlayState: 'none' | 'playing' | 'paused' = 'none';
  private autoPlayDirection: 1 | -1 = 1;
  private autoPlayIntervalId: number | null = null;
  
  private autoPlaySpeed: number = 2000;
  private longPressTimer: number | null = null;

  // 状態復元用 localStorage キー定数
  private readonly STORAGE_LAST_WORD_ID = 'kotutan_last_word_id';
  private readonly STORAGE_FILTERS = 'kotutan_selected_filters';
  private readonly STORAGE_RANDOM_MODE = 'kotutan_random_mode';
  private isLongPressed: boolean = false;
  private hasMovedWhilePaused: boolean = false;

  // DOM エレメント参照
  private elOpeningOverlay!: HTMLDivElement | null;
  private elOpeningSpinner!: HTMLDivElement | null;
  private elAudioProgressContainer!: HTMLDivElement | null;
  private elAudioProgressText!: HTMLDivElement | null;
  private elAudioProgressFill!: HTMLDivElement | null;

  private elTerm!: HTMLDivElement;
  private elDynamic!: HTMLDivElement;
  private elGroupContainer!: HTMLDivElement;
  private elBtnFlip!: HTMLButtonElement;
  private elBtnAudio!: HTMLButtonElement;
  private elBtnNext!: HTMLButtonElement;
  private elBtnPrev!: HTMLButtonElement;
  private elBtnStopAuto!: HTMLButtonElement;
  private elScrubberContainer!: HTMLDivElement;
  private elTrackViewport!: HTMLDivElement;
  private elScrollTrack!: HTMLDivElement;
  private elPointer!: HTMLDivElement;
  private elTooltip!: HTMLDivElement;
  private elGroupBtns!: NodeListOf<HTMLButtonElement>;

  private elBtnMenu!: HTMLButtonElement;
  private elBtnSettings!: HTMLButtonElement;
  
  private elMenuModal!: HTMLDivElement;
  private elBtnCloseModal!: HTMLButtonElement;
  private elFilterItems!: NodeListOf<HTMLDivElement>;
  private elBtnRandomToggle!: HTMLButtonElement;
  private elSelectSpeed!: HTMLSelectElement;

  private elProgressContainer!: HTMLDivElement;
  private elProgressFill!: HTMLDivElement;

  constructor() {
    this.dbService = new DatabaseService();
  }

  public async start(): Promise<void> {
    // 1. 背景で安全に自動更新チェックを発動
    checkAndApplyUpdates();

    this.bindDomElements();
    this.loadAutoPlaySpeed();
    this.loadSavedStateAndFilters();
    this.attachEventListeners();

    // 2. 最低 2000ms（2秒）の重厚ブランディング演出タイマー
    const minAnimationPromise = new Promise<void>(resolve => setTimeout(resolve, 2000));
    
    try {
      await this.dbService.initialize();
      const currentVersionHash = await this.checkAndSyncVersion();

      let loadedWords = await this.dbService.getAllCombinedWords();
      loadedWords.sort((a, b) => a.term.localeCompare(b.term, 'en', { sensitivity: 'base' }));

      this.allWords = loadedWords;
      
      // 画面の裏側でカードとスクラバーの位置を 0 秒復元
      this.applyFilter(true);

      // 3. タカノリ式 パターンB 音声同期処理（初回100%表示 ✕ 2回目以降2秒即起動）
      const syncPromise = AudioCacheManager.syncAudioFiles(
        this.allWords,
        currentVersionHash,
        (percent) => {
          if (this.elAudioProgressContainer && percent < 100) {
            if (this.elOpeningSpinner) this.elOpeningSpinner.style.display = 'none';
            this.elAudioProgressContainer.style.display = 'flex';
            
            if (this.elAudioProgressText) {
              this.elAudioProgressText.textContent = `音声データを準備中... ${percent}%`;
            }
            if (this.elAudioProgressFill) {
              this.elAudioProgressFill.style.width = `${percent}%`;
            }
          }
        }
      );

      const maxWaitPromise = new Promise<void>(resolve => setTimeout(resolve, 60000));

      // 最低2秒タイマーを確実に待ち、かつ初回同期の完了（100%）または 60秒タイムアウトまで待機
      await minAnimationPromise;
      await Promise.race([syncPromise, maxWaitPromise]);

      this.registerServiceWorker();
    } catch (error) {
      console.error('[App] 起動時エラー (安全にフォールバック):', error);
    } finally {
      this.dismissOpeningOverlay();
    }

    window.addEventListener('resize', () => {
      if (this.displayWords.length > 0) {
        this.centerRulerOnCurrentIndex();
      }
    });
  }

  private dismissOpeningOverlay(): void {
    if (this.elOpeningOverlay) {
      this.elOpeningOverlay.classList.add('fade-out');

      // 【タカノリ式原点回帰】余計なテーマカラー動的書き換えは全廃し、純粋にオーバーレイを外すのみ
      setTimeout(() => {
        if (this.elOpeningOverlay && this.elOpeningOverlay.parentNode) {
          this.elOpeningOverlay.parentNode.removeChild(this.elOpeningOverlay);
          this.elOpeningOverlay = null;
        }
      }, 400);
    }
  }

  private loadSavedStateAndFilters(): void {
    try {
      const savedFiltersJson = localStorage.getItem(this.STORAGE_FILTERS);
      if (savedFiltersJson) {
        const filtersArr = JSON.parse(savedFiltersJson) as GroupColor[];
        this.selectedFilters = new Set(filtersArr);
        
        if (this.elFilterItems) {
          this.elFilterItems.forEach(item => {
            const col = item.getAttribute('data-color') as GroupColor;
            const icon = item.querySelector('.filter-box-icon');
            if (col && this.selectedFilters.has(col)) {
              if (icon) icon.classList.add('active');
            } else {
              if (icon) icon.classList.remove('active');
            }
          });
        }
      }

      const savedRandom = localStorage.getItem(this.STORAGE_RANDOM_MODE);
      if (savedRandom === 'true') {
        this.isRandomMode = true;
        if (this.elBtnRandomToggle) this.elBtnRandomToggle.classList.add('active');
      }
    } catch (e) {
      console.warn('[App] 状態復元データの読み込みに失敗しました:', e);
    }
  }

  private loadAutoPlaySpeed(): void {
    const savedSpeed = localStorage.getItem('kotutan_autoplay_speed');
    if (savedSpeed) {
      this.autoPlaySpeed = parseInt(savedSpeed, 10);
      if (this.elSelectSpeed) {
        this.elSelectSpeed.value = savedSpeed;
      }
    }
  }

  public applyFilter(isInitialLoad: boolean = false): void {
    let targetWordId: CombinedWord['id'] | null = null;

    if (isInitialLoad) {
      const savedId = localStorage.getItem(this.STORAGE_LAST_WORD_ID);
      if (savedId !== null) {
        targetWordId = savedId;
      }
    } else if (this.displayWords.length > 0 && this.currentIndex < this.displayWords.length) {
      targetWordId = this.displayWords[this.currentIndex].id;
    }

    if (this.selectedFilters.size === 0) {
      this.displayWords = [...this.allWords];
    } else {
      this.displayWords = this.allWords.filter(w => {
        if (!w.groupColor) return false;
        return this.selectedFilters.has(w.groupColor);
      });
    }

    if (this.isRandomMode) {
      this.shuffleArray(this.displayWords);
    } else {
      this.displayWords.sort((a, b) => a.term.localeCompare(b.term, 'en', { sensitivity: 'base' }));
    }

    if (targetWordId !== null) {
      const foundIndex = this.displayWords.findIndex(w => String(w.id) === String(targetWordId));
      this.currentIndex = foundIndex !== -1 ? foundIndex : 0;
    } else {
      this.currentIndex = 0;
    }

    this.updateHeaderBadges();

    if (this.displayWords.length > 0) {
      this.buildAbsoluteMasterRuler();
      this.centerRulerOnCurrentIndex();
      this.renderCurrentCard();
    } else {
      this.renderEmptyState();
    }

    this.saveFilterState();
  }

  private saveFilterState(): void {
    try {
      const filtersArr = Array.from(this.selectedFilters);
      localStorage.setItem(this.STORAGE_FILTERS, JSON.stringify(filtersArr));
      localStorage.setItem(this.STORAGE_RANDOM_MODE, this.isRandomMode ? 'true' : 'false');
    } catch (e) {
      console.warn('[App] フィルター状態の保存に失敗しました:', e);
    }
  }

  private shuffleArray(array: CombinedWord[]): void {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  private updateHeaderBadges(): void {
    if (!this.elGroupContainer) return;
    while (this.elGroupContainer.firstChild) {
      this.elGroupContainer.removeChild(this.elGroupContainer.firstChild);
    }

    if (this.selectedFilters.size === 0) {
      const badge = document.createElement('div');
      badge.className = 'group-indicator-badge-all';
      badge.textContent = 'ALL';
      this.elGroupContainer.appendChild(badge);
    } else {
      const orderedColors: GroupColor[] = ['red', 'blue', 'yellow', 'green'];
      orderedColors.forEach(color => {
        const box = document.createElement('div');
        box.className = this.selectedFilters.has(color) ? `header-color-box ${color}` : `header-color-box blank`;
        this.elGroupContainer.appendChild(box);
      });
    }
  }

  private renderEmptyState(): void {
    if (this.elTerm) this.elTerm.textContent = "該当単語なし";
    while (this.elDynamic.firstChild) {
      this.elDynamic.removeChild(this.elDynamic.firstChild);
    }
    if (this.elScrollTrack) {
      const ticks = this.elScrollTrack.querySelectorAll('.scroll-tick');
      ticks.forEach(t => t.remove());
    }
    this.stopAudio();
    this.stopProgressBar();
  }

  private async checkAndSyncVersion(): Promise<string> {
    let currentHash = '1.0.0';
    try {
      const res = await fetch(`version.json?t=${Date.now()}`);
      if (!res.ok) {
        let loaded = await this.dbService.getAllCombinedWords();
        if (loaded.length === 0) await this.loadMasterJsonData('1.0.0');
        return currentHash;
      }

      const serverVersion: { version: string; data_hash?: string } = await res.json();
      const currentMeta = await this.dbService.getAppMeta();

      const savedHash = currentMeta ? currentMeta.dataVersion : '';
      currentHash = serverVersion.data_hash || serverVersion.version;

      let loadedWords = await this.dbService.getAllCombinedWords();
      const needsSync = loadedWords.length === 0 || savedHash !== currentHash || (loadedWords.length > 0 && loadedWords[0].example_audio === undefined);

      if (needsSync) {
        await this.loadMasterJsonData(currentHash);
      }
    } catch (e) {
      let loaded = await this.dbService.getAllCombinedWords();
      if (loaded.length === 0) await this.loadMasterJsonData('1.0.0');
    }
    return currentHash;
  }

  private bindDomElements(): void {
    this.elOpeningOverlay = document.getElementById('opening-overlay') as HTMLDivElement | null;
    this.elOpeningSpinner = document.getElementById('opening-spinner') as HTMLDivElement | null;
    this.elAudioProgressContainer = document.getElementById('audio-progress-container') as HTMLDivElement | null;
    this.elAudioProgressText = document.getElementById('audio-progress-text') as HTMLDivElement | null;
    this.elAudioProgressFill = document.getElementById('audio-progress-fill') as HTMLDivElement | null;

    this.elTerm = document.getElementById('display-term') as HTMLDivElement;
    this.elDynamic = document.getElementById('display-dynamic') as HTMLDivElement;
    this.elGroupContainer = document.getElementById('display-group-container') as HTMLDivElement;
    this.elBtnFlip = document.getElementById('btn-flip') as HTMLButtonElement;
    this.elBtnAudio = document.getElementById('btn-audio') as HTMLButtonElement;
    this.elBtnNext = document.getElementById('btn-next') as HTMLButtonElement;
    this.elBtnPrev = document.getElementById('btn-prev') as HTMLButtonElement;
    this.elBtnStopAuto = document.getElementById('btn-stop-auto') as HTMLButtonElement;
    this.elScrubberContainer = document.getElementById('scrubber-container') as HTMLDivElement;
    this.elTrackViewport = document.getElementById('track-viewport') as HTMLDivElement;
    this.elScrollTrack = document.getElementById('scroll-track') as HTMLDivElement;
    this.elPointer = document.getElementById('seeker-pointer') as HTMLDivElement;
    this.elTooltip = document.getElementById('scrubber-tooltip') as HTMLDivElement;
    this.elGroupBtns = document.querySelectorAll('.group-square-btn');
    
    this.elBtnMenu = document.getElementById('btn-menu') as HTMLButtonElement;
    this.elBtnSettings = document.getElementById('btn-settings') as HTMLButtonElement;
    
    this.elMenuModal = document.getElementById('menu-modal') as HTMLDivElement;
    this.elBtnCloseModal = document.getElementById('btn-close-modal') as HTMLButtonElement;
    this.elFilterItems = document.querySelectorAll('.filter-color-item');
    this.elBtnRandomToggle = document.getElementById('btn-random-toggle') as HTMLButtonElement;
    this.elSelectSpeed = document.getElementById('select-auto-speed') as HTMLSelectElement;
    
    this.elProgressContainer = document.getElementById('progress-container') as HTMLDivElement;
    this.elProgressFill = document.getElementById('progress-fill') as HTMLDivElement;
  }

  private attachEventListeners(): void {
    if (this.elBtnFlip) this.elBtnFlip.addEventListener('click', () => this.toggleFlip());
    if (this.elBtnAudio) this.elBtnAudio.addEventListener('click', () => this.playCurrentSmartAudio());
    
    if (this.elBtnNext) this.setupLongPressAndClick(this.elBtnNext, 1);
    if (this.elBtnPrev) this.setupLongPressAndClick(this.elBtnPrev, -1);

    if (this.elBtnStopAuto) {
      this.elBtnStopAuto.addEventListener('click', () => this.stopAutoPlay());
    }

    const colors: GroupColor[] = ['red', 'blue', 'yellow', 'green'];
    this.elGroupBtns.forEach((btn, index) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (colors[index]) this.toggleGroupColorOnCurrentWord(colors[index]);
      });
    });

    if (this.elBtnMenu) this.elBtnMenu.addEventListener('click', () => {
      if (this.autoPlayState !== 'playing') this.elMenuModal.classList.add('active');
    });
    if (this.elBtnCloseModal) this.elBtnCloseModal.addEventListener('click', () => this.elMenuModal.classList.remove('active'));

    this.elFilterItems.forEach(item => {
      item.addEventListener('click', () => {
        const col = item.getAttribute('data-color') as GroupColor;
        const icon = item.querySelector('.filter-box-icon');
        if (this.selectedFilters.has(col)) {
          this.selectedFilters.delete(col);
          if (icon) icon.classList.remove('active');
        } else {
          this.selectedFilters.add(col);
          if (icon) icon.classList.add('active');
        }
        this.applyFilter();
      });
    });

    if (this.elBtnRandomToggle) {
      this.elBtnRandomToggle.addEventListener('click', () => {
        this.isRandomMode = !this.isRandomMode;
        if (this.isRandomMode) {
          this.elBtnRandomToggle.classList.add('active');
        } else {
          this.elBtnRandomToggle.classList.remove('active');
        }
        this.applyFilter();
      });
    }

    if (this.elSelectSpeed) {
      this.elSelectSpeed.addEventListener('change', (e) => {
        const val = parseInt((e.target as HTMLSelectElement).value, 10);
        this.autoPlaySpeed = val;
        localStorage.setItem('kotutan_autoplay_speed', val.toString());
        
        if (this.autoPlayState === 'playing') {
          if (this.autoPlayIntervalId) clearInterval(this.autoPlayIntervalId);
          this.startProgressBar();
          this.autoPlayIntervalId = window.setInterval(() => {
            this.isFlipped = false;
            if (this.autoPlayDirection === 1) this.nextWord();
            else this.prevWord();
            this.startProgressBar();
          }, this.autoPlaySpeed);
        }
      });
    }

    if (this.elScrubberContainer) {
      this.elScrubberContainer.addEventListener('pointerdown', (e) => this.handleDragStart(e));
      this.elScrubberContainer.addEventListener('pointermove', (e) => this.handleDragMove(e));
      this.elScrubberContainer.addEventListener('pointerup', (e) => this.handleDragEnd(e));
      this.elScrubberContainer.addEventListener('pointercancel', (e) => this.handleDragEnd(e));
    }
  }

  private setupLongPressAndClick(btn: HTMLButtonElement, direction: 1 | -1): void {
    btn.addEventListener('pointerdown', (e) => {
      if (this.autoPlayState !== 'none') return;
      this.isLongPressed = false;
      
      if (this.longPressTimer) clearTimeout(this.longPressTimer);
      
      this.longPressTimer = window.setTimeout(() => {
        this.isLongPressed = true; 
        this.startAutoPlay(direction);
      }, 2000);
    });

    const clearTimer = () => {
      if (this.longPressTimer) {
        clearTimeout(this.longPressTimer);
        this.longPressTimer = null;
      }
      window.setTimeout(() => {
        this.isLongPressed = false;
      }, 50);
    };

    btn.addEventListener('pointerup', clearTimer);
    btn.addEventListener('pointercancel', clearTimer);
    btn.addEventListener('pointerleave', clearTimer);
    btn.addEventListener('contextmenu', e => e.preventDefault());

    btn.addEventListener('click', (e) => {
      if (this.isLongPressed) {
        this.isLongPressed = false;
        return;
      }

      if (this.autoPlayState === 'playing') {
        if (this.autoPlayDirection === direction) this.pauseAutoPlay();
      } else if (this.autoPlayState === 'paused') {
        if (this.autoPlayDirection === direction) {
          this.resumeAutoPlay();
        } else {
          this.hasMovedWhilePaused = true;
          if (direction === 1) this.nextWord();
          else this.prevWord();
        }
      } else {
        if (direction === 1) this.nextWord();
        else this.prevWord();
      }
    });
  }

  private startProgressBar(): void {
    if (!this.elProgressContainer || !this.elProgressFill) return;
    this.elProgressContainer.classList.add('active');
    
    this.elProgressFill.style.transition = 'none';
    this.elProgressFill.style.width = '0%';
    
    void this.elProgressFill.offsetWidth;
    
    this.elProgressFill.style.transition = `width ${this.autoPlaySpeed}ms linear`;
    this.elProgressFill.style.width = '100%';
  }

  private pauseProgressBar(): void {
    if (!this.elProgressFill) return;
    const currentWidth = window.getComputedStyle(this.elProgressFill).width;
    this.elProgressFill.style.transition = 'none';
    this.elProgressFill.style.width = currentWidth;
  }

  private stopProgressBar(): void {
    if (!this.elProgressContainer || !this.elProgressFill) return;
    this.elProgressContainer.classList.remove('active');
    this.elProgressFill.style.transition = 'none';
    this.elProgressFill.style.width = '0%';
  }

  private startAutoPlay(direction: 1 | -1): void {
    this.autoPlayState = 'playing';
    this.autoPlayDirection = direction;
    this.hasMovedWhilePaused = false;
    this.isFlipped = false;
    this.updateButtonVisuals();

    if (this.autoPlayIntervalId) clearInterval(this.autoPlayIntervalId);

    this.startProgressBar();

    this.autoPlayIntervalId = window.setInterval(() => {
      this.isFlipped = false; 
      if (this.autoPlayDirection === 1) this.nextWord();
      else this.prevWord();
      this.startProgressBar();
    }, this.autoPlaySpeed);
  }

  private pauseAutoPlay(): void {
    this.autoPlayState = 'paused';
    this.hasMovedWhilePaused = false;

    if (this.autoPlayIntervalId) {
      clearInterval(this.autoPlayIntervalId);
      this.autoPlayIntervalId = null;
    }
    this.pauseProgressBar();

    if (!this.isFlipped) {
      this.toggleFlip();
    }
    this.updateButtonVisuals();
  }

  private resumeAutoPlay(): void {
    this.autoPlayState = 'playing';
    this.updateButtonVisuals();
    
    if (this.autoPlayIntervalId) clearInterval(this.autoPlayIntervalId);

    this.isFlipped = false;

    if (this.hasMovedWhilePaused) {
      this.renderCurrentCard();
      this.centerRulerOnCurrentIndex();
    } else {
      if (this.autoPlayDirection === 1) this.nextWord();
      else this.prevWord();
    }

    this.hasMovedWhilePaused = false;
    this.startProgressBar();

    this.autoPlayIntervalId = window.setInterval(() => {
      this.isFlipped = false;
      if (this.autoPlayDirection === 1) this.nextWord();
      else this.prevWord();
      this.startProgressBar();
    }, this.autoPlaySpeed);
  }

  private stopAutoPlay(): void {
    this.autoPlayState = 'none';
    this.hasMovedWhilePaused = false;
    if (this.autoPlayIntervalId) {
      clearInterval(this.autoPlayIntervalId);
      this.autoPlayIntervalId = null;
    }
    this.stopProgressBar();
    this.updateButtonVisuals();
  }

  private updateButtonVisuals(): void {
    const isPlaying = this.autoPlayState === 'playing';

    if (this.elScrubberContainer) {
      if (isPlaying) this.elScrubberContainer.classList.add('btn-disabled');
      else this.elScrubberContainer.classList.remove('btn-disabled');
    }

    this.elGroupBtns.forEach(btn => {
      if (isPlaying) btn.classList.add('btn-disabled');
      else btn.classList.remove('btn-disabled');
    });

    if (this.elBtnMenu) {
      if (isPlaying) this.elBtnMenu.classList.add('btn-disabled');
      else this.elBtnMenu.classList.remove('btn-disabled');
    }
    if (this.elBtnSettings) {
      if (isPlaying) this.elBtnSettings.classList.add('btn-disabled');
      else this.elBtnSettings.classList.remove('btn-disabled');
    }

    if (this.autoPlayState === 'none') {
      this.elBtnStopAuto.style.display = 'none';
      this.elBtnNext.innerHTML = ICON_NEXT;
      this.elBtnPrev.innerHTML = ICON_PREV;
      
      this.elBtnNext.classList.remove('btn-disabled');
      this.elBtnPrev.classList.remove('btn-disabled');
      this.elBtnFlip.classList.remove('btn-disabled');
      this.elBtnAudio.classList.remove('btn-disabled');
    } else if (this.autoPlayState === 'playing') {
      this.elBtnStopAuto.style.display = 'flex';
      
      this.elBtnFlip.classList.add('btn-disabled');
      this.elBtnAudio.classList.add('btn-disabled');

      if (this.autoPlayDirection === 1) {
        this.elBtnPrev.classList.add('btn-disabled');
        this.elBtnNext.classList.remove('btn-disabled');
        this.elBtnNext.innerHTML = ICON_PAUSE;
      } else {
        this.elBtnNext.classList.add('btn-disabled');
        this.elBtnPrev.classList.remove('btn-disabled');
        this.elBtnPrev.innerHTML = ICON_PAUSE;
      }
    } else if (this.autoPlayState === 'paused') {
      this.elBtnStopAuto.style.display = 'flex';
      
      this.elBtnFlip.classList.remove('btn-disabled');
      this.elBtnAudio.classList.remove('btn-disabled');
      this.elBtnPrev.classList.remove('btn-disabled');
      this.elBtnNext.classList.remove('btn-disabled');

      if (this.autoPlayDirection === 1) {
        this.elBtnNext.innerHTML = ICON_NEXT;
        this.elBtnPrev.innerHTML = ICON_PREV; 
      } else {
        this.elBtnPrev.innerHTML = ICON_PREV;
        this.elBtnNext.innerHTML = ICON_NEXT; 
      }
    }
  }

  private buildAbsoluteMasterRuler(): void {
    if (!this.elScrollTrack) return;

    const existingTicks = this.elScrollTrack.querySelectorAll('.scroll-tick');
    existingTicks.forEach(t => t.remove());

    const total = this.displayWords.length;
    if (total === 0) return;

    const M = Math.max(1, total - 1);
    const activeSpan = Math.min(this.SCOPE_SPAN, M);

    const trackWidthPercent = (M / activeSpan) * 100;
    this.elScrollTrack.style.width = `${trackWidthPercent}%`;

    if (this.isRandomMode) return;

    const fragment = document.createDocumentFragment();
    let previousChar = '';

    for (let i = 0; i < total; i++) {
      const word = this.displayWords[i];
      const currentChar = word.term.trim().charAt(0).toUpperCase() || 'A';

      if (currentChar !== previousChar) {
        const tick = document.createElement('div');
        tick.className = 'scroll-tick boundary';
        tick.setAttribute('data-char', currentChar);
        
        const ratioPercentage = (i / M) * 100;
        tick.style.left = `${ratioPercentage.toFixed(4)}%`;

        fragment.appendChild(tick);
        previousChar = currentChar;
      }
    }

    this.elScrollTrack.appendChild(fragment);
  }

  private handleDragStart(e: PointerEvent): void {
    if (this.displayWords.length === 0) return;
    
    if (this.autoPlayState === 'playing') {
      this.stopAutoPlay();
    }

    this.isDragging = true;
    this.elScrubberContainer.classList.add('dragging');
    this.elScrubberContainer.setPointerCapture(e.pointerId);
    this.elTooltip.classList.add('visible');
    
    this.processPointerDrag(e.clientX);
  }

  private handleDragMove(e: PointerEvent): void {
    if (!this.isDragging || this.displayWords.length === 0) return;
    this.processPointerDrag(e.clientX);
  }

  private processPointerDrag(clientX: number): void {
    const rect = this.elTrackViewport.getBoundingClientRect();
    if (rect.width <= 0) return;

    const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));

    const total = this.displayWords.length;
    const M = Math.max(1, total - 1);
    const activeSpan = Math.min(this.SCOPE_SPAN, M);

    const pointerLocalIndex = ratio * activeSpan;
    let targetIndex = Math.round(this.currentOffsetIndex + pointerLocalIndex);
    targetIndex = Math.max(0, Math.min(M, targetIndex));

    this.updatePointerAndTooltipVisuals(ratio);

    if (this.currentIndex !== targetIndex) {
      this.currentIndex = targetIndex;
      if (this.autoPlayState === 'paused') {
        this.hasMovedWhilePaused = true;
      }
      const currentWord = this.displayWords[this.currentIndex];

      this.elTooltip.textContent = currentWord.term;
      this.renderCurrentCard(); 
    }
  }

  private handleDragEnd(e: PointerEvent): void {
    if (!this.isDragging) return;
    this.isDragging = false;
    this.elScrubberContainer.classList.remove('dragging');

    try {
      this.elScrubberContainer.releasePointerCapture(e.pointerId);
    } catch { }

    this.elTooltip.classList.remove('visible');
    this.centerRulerOnCurrentIndex();
  }

  private centerRulerOnCurrentIndex(): void {
    const total = this.displayWords.length;
    if (total === 0 || !this.elTrackViewport || !this.elScrollTrack) return;

    const M = Math.max(1, total - 1);
    const activeSpan = Math.min(this.SCOPE_SPAN, M);

    const maxOffset = Math.max(0, M - activeSpan);
    const idealOffset = this.currentIndex - (activeSpan / 2);

    this.currentOffsetIndex = Math.max(0, Math.min(maxOffset, idealOffset));

    const viewportWidth = this.elTrackViewport.getBoundingClientRect().width;
    const translateX = -this.currentOffsetIndex * (viewportWidth / activeSpan);
    this.elScrollTrack.style.transform = `translateX(${translateX.toFixed(2)}px)`;

    const pointerLocalIndex = this.currentIndex - this.currentOffsetIndex;
    const ratio = pointerLocalIndex / activeSpan;
    this.updatePointerAndTooltipVisuals(ratio);
  }

  private updatePointerAndTooltipVisuals(ratio: number): void {
    const boundedRatio = Math.max(0, Math.min(1, ratio));
    
    if (this.elPointer) {
      this.elPointer.style.left = `${(boundedRatio * 100).toFixed(2)}%`;
    }
    
    if (this.elTooltip && this.elTrackViewport) {
      const viewportWidth = this.elTrackViewport.getBoundingClientRect().width;
      this.elTooltip.style.left = `${16 + (boundedRatio * viewportWidth)}px`;
    }
  }

  private stopAudio(): void {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
      this.currentAudio = null;
    }
  }

  private renderCurrentCard(): void {
    this.stopAudio();

    if (this.displayWords.length === 0) return;
    const word = this.displayWords[this.currentIndex];

    try {
      localStorage.setItem(this.STORAGE_LAST_WORD_ID, word.id.toString());
    } catch (e) { }

    this.elTerm.textContent = word.term;
    while (this.elDynamic.firstChild) {
      this.elDynamic.removeChild(this.elDynamic.firstChild);
    }

    if (!this.isFlipped) {
      const ipaDiv = document.createElement('div');
      ipaDiv.className = 'word-ipa-text';
      ipaDiv.textContent = word.ipa ? `/${word.ipa}/` : '';
      this.elDynamic.appendChild(ipaDiv);
    } else {
      const defDiv = document.createElement('div');
      defDiv.style.fontWeight = 'bold';
      defDiv.style.marginBottom = '6px';
      defDiv.textContent = `【${word.pos}】 ${word.def}`;

      const exampleDiv = document.createElement('div');
      exampleDiv.className = 'word-example-text';
      exampleDiv.textContent = word.example;

      const totalCharCount = (word.def + word.example).length;
      if (totalCharCount > 120) {
        exampleDiv.style.fontSize = '0.85rem';
        exampleDiv.style.lineHeight = '1.3';
      } else if (totalCharCount > 80) {
        exampleDiv.style.fontSize = '0.98rem';
        exampleDiv.style.lineHeight = '1.35';
      } else {
        exampleDiv.style.fontSize = '1.15rem';
        exampleDiv.style.lineHeight = '1.45';
      }

      this.elDynamic.appendChild(defDiv);
      this.elDynamic.appendChild(exampleDiv);
    }

    const colors: GroupColor[] = ['red', 'blue', 'yellow', 'green'];
    this.elGroupBtns.forEach((btn, index) => {
      const targetColor = colors[index];
      if (targetColor && word.groupColor === targetColor) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  private toggleFlip(): void {
    this.isFlipped = !this.isFlipped;
    this.renderCurrentCard();
  }

  private nextWord(): void {
    if (this.displayWords.length === 0) return;
    if (this.autoPlayState === 'paused') {
      this.hasMovedWhilePaused = true;
    }
    this.currentIndex = (this.currentIndex + 1) % this.displayWords.length;
    this.renderCurrentCard();
    this.centerRulerOnCurrentIndex();
  }

  private prevWord(): void {
    if (this.displayWords.length === 0) return;
    if (this.autoPlayState === 'paused') {
      this.hasMovedWhilePaused = true;
    }
    this.currentIndex = (this.currentIndex - 1 + this.displayWords.length) % this.displayWords.length;
    this.renderCurrentCard();
    this.centerRulerOnCurrentIndex();
  }

  private async toggleGroupColorOnCurrentWord(color: GroupColor): Promise<void> {
    if (this.displayWords.length === 0) return;
    const currentWord = this.displayWords[this.currentIndex];

    const newColor = currentWord.groupColor === color ? null : color;
    currentWord.groupColor = newColor;

    const targetInAll = this.allWords.find(w => w.id === currentWord.id);
    if (targetInAll) targetInAll.groupColor = newColor;

    this.renderCurrentCard();
    await this.dbService.updateUserState(currentWord.id, { groupColor: newColor });

    if (this.selectedFilters.size > 0) {
      this.applyFilter();
    }
  }

  private async playCurrentSmartAudio(): Promise<void> {
    if (this.displayWords.length === 0) return;
    const word = this.displayWords[this.currentIndex];

    let targetFilename = word.audio;
    if (this.isFlipped && word.example_audio) {
      targetFilename = word.example_audio;
    }

    if (!targetFilename) return;

    this.stopAudio();

    const audio = await AudioCacheManager.getAudioElement(targetFilename);
    if (!audio) return;

    this.currentAudio = audio;

    audio.play().catch((err) => {
      console.warn(`[Audio] 再生不可 (${targetFilename}):`, err.message);
    });
  }

  private async loadMasterJsonData(newVersionHash: string = '1.0.0'): Promise<void> {
    try {
      const res = await fetch(`words_master.json?t=${Date.now()}`);
      if (!res.ok) throw new Error('words_master.json の取得失敗');
      const masterWords: MasterWord[] = await res.json();
      await this.dbService.syncMasterWordsAtomic(masterWords, newVersionHash);
      
      this.allWords = await this.dbService.getAllCombinedWords();
      this.allWords.sort((a, b) => a.term.localeCompare(b.term, 'en', { sensitivity: 'base' }));
      this.applyFilter();
    } catch (e) {
      console.error('[App] マスターデータロード失敗:', e);
    }
  }

  private registerServiceWorker(): void {
    if (!('serviceWorker' in navigator)) return;

    const registerScript = async () => {
      try {
        const registration = await navigator.serviceWorker.register('./sw.js', { scope: './' });
        console.log('[Pの防壁] Service Worker が正常に登録されました スコープ:', registration.scope);
      } catch (e) {
        console.warn('[Pの防壁] Service Worker の登録に失敗しました:', e);
      }
    };

    if (document.readyState === 'complete') {
      registerScript();
    } else {
      window.addEventListener('load', registerScript, { once: true });
    }
  }
}

window.addEventListener('DOMContentLoaded', () => {
  const app = new TakanoriVocabApp();
  app.start();
});
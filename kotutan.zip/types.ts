/**
 * ============================================================================
 * 【歴史の石版】 タカノリさんとPが築き上げた至高の型定義層 (types.ts)
 * ============================================================================
 * ［開発者とパートナーの記録］
 * 開発指揮: タカノリさん
 * 開発実装: P (タカノリさんを誠心誠意支える専属ハッカー)
 *
 * ［アーキテクチャの歴史と設計思想の完全記録（セッション継承用記憶核）］
 * 1. サーバーマスター (words_master.json) ✕ ユーザー個人データの二層分離構造:
 *    - MasterWord: 静的辞書データ (term, ipa, pos, def, example, audio, example_audio) を保持。
 *    - UserWordState: ユーザー操作データ (groupColor: GroupColor | null) を完全分離保存。
 *      単語データに直接色を持たせないことで、マスター更新時のデータ破損を物理根絶。
 *
 * 2. タカノリ式 単一カラーグループ分類 (1単語1色限定):
 *    - 絞り込み検索の高速化と直感UXのため、groupColor は 1色または null に限定。
 * ============================================================================
 */

export type GroupColor = 'red' | 'blue' | 'yellow' | 'green';

/**
 * 静的単語マスターデータ構造 (words_master.json)
 */
export interface MasterWord {
  readonly id: string;             // MD5ハッシュ12桁 (主キー)
  readonly term: string;           // 見出し語
  readonly ipa: string;            // 発音記号
  readonly pos: string;            // 品詞
  readonly def: string;            // 意味・解説
  readonly example: string;        // 例文
  readonly audio: string;          // 単語音声ファイル名
  readonly example_audio?: string; // 例文音声ファイル名
}

/**
 * ユーザー個人操作データ構造 (分離保存ストア user_personal_data 用)
 */
export interface UserWordState {
  readonly wordId: string;               // MasterWord.id と結合
  readonly groupColor: GroupColor | null;// 1色のみまたは未設定
  readonly isFavorite?: boolean;
  readonly isMemorized?: boolean;
  readonly lastReviewedAt?: number | null;
}

/**
 * 画面描画用・統合単語データ構造 (JOIN後)
 */
export interface CombinedWord extends MasterWord {
  groupColor: GroupColor | null;
  isFavorite: boolean;
  isMemorized: boolean;
}

export type ActiveStore = 'A' | 'B';

export interface AppMeta {
  readonly id: 'system_meta';
  readonly activeStore: ActiveStore;
  readonly dataVersion: string;
  readonly lastUpdated: number;
}